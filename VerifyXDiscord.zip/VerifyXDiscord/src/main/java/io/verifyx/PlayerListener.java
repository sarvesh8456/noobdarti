/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 */
package io.verifyx;

import io.verifyx.Main;
import io.verifyx.VerificationManager;
import io.verifyx.tab.VerifyTab;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerListener
implements Listener {
    private final Main plugin;
    private final VerificationManager verificationManager;
    private VerifyTab verifyTab;

    public PlayerListener(Main plugin) {
        this.plugin = plugin;
        this.verificationManager = plugin.getVerificationManager();
        if (plugin.getVerifyTab() != null) {
            this.verifyTab = plugin.getVerifyTab();
        } else {
            plugin.getLogger().warning("VerifyTab not available - tab features disabled");
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerJoin(PlayerJoinEvent event) {
        event.setJoinMessage(null);
        if (this.verificationManager == null) {
            this.plugin.getLogger().warning("VerificationManager not ready for player join: " + event.getPlayer().getName());
            return;
        }
        if (this.verifyTab != null) {
            this.verifyTab.onPlayerJoin(event.getPlayer());
        }
        this.verificationManager.handlePlayerJoin(event.getPlayer());
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerQuit(PlayerQuitEvent event) {
        event.setQuitMessage(null);
        if (this.verifyTab != null) {
            this.verifyTab.onPlayerQuit(event.getPlayer());
        }
    }
}

