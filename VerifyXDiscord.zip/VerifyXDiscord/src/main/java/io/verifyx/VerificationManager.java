/*
 * Decompiled with CFR.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package io.verifyx;

import io.verifyx.DatabaseManager;
import io.verifyx.Main;
import io.verifyx.OTPManager;
import io.verifyx.WorldManager;
import io.verifyx.security.AISecurityManager;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.concurrent.TimeUnit;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.Cache;
import java.lang.reflect.Method;

public class VerificationManager {
    private final Main plugin;
    private final DatabaseManager databaseManager;
    private final OTPManager otpManager;
    private final AISecurityManager aiSecurityManager;
    private WorldManager worldManager;
    private boolean worldManagerInitializing = false;
    private boolean worldManagerReady = false;

    public VerificationManager(Main plugin, DatabaseManager databaseManager, OTPManager otpManager, AISecurityManager aiSecurityManager) {
        this.plugin = plugin;
        this.databaseManager = databaseManager;
        this.otpManager = otpManager;
        this.aiSecurityManager = aiSecurityManager;
        // load cache configuration
        try {
            this.cacheTtlSeconds = Math.max(10, this.plugin.getConfig().getInt("performance.cache-ttl-seconds", 300));
            this.cacheCleanupIntervalMinutes = Math.max(1, this.plugin.getConfig().getInt("performance.cleanup-interval-minutes", 5));
        } catch (Exception e) {
            this.cacheTtlSeconds = 300;
            this.cacheCleanupIntervalMinutes = 5;
        }
        // detect optional integration plugins (can be disabled via config)
        try {
            boolean enableIntegrations = true;
            try {
                enableIntegrations = this.plugin.getConfig().getBoolean("integrations.enable-via-geyser", true);
            } catch (Exception cfgEx) {
                enableIntegrations = true;
            }
            if (enableIntegrations) {
                this.viaPresent = Bukkit.getPluginManager().getPlugin("ViaVersion") != null || Bukkit.getPluginManager().getPlugin("viaversion") != null;
                this.geyserPresent = Bukkit.getPluginManager().getPlugin("Geyser-Spigot") != null || Bukkit.getPluginManager().getPlugin("Geyser") != null;
            } else {
                this.viaPresent = false;
                this.geyserPresent = false;
            }
            if (this.plugin.getConfig().getBoolean("logging.log-verifications", true)) {
                this.plugin.getLogger().info("[VerifyX] ViaVersion present: " + this.viaPresent + ", Geyser present: " + this.geyserPresent + ", integrations.enabled:" + enableIntegrations);
            }
        } catch (Exception ex) {
            this.viaPresent = false;
            this.geyserPresent = false;
        }

        // init caffeine cache
        int maxSize = Math.max(1000, this.plugin.getConfig().getInt("ai-security.max-cache-size", 10000));
        this.verifiedCache = Caffeine.newBuilder().expireAfterWrite(this.cacheTtlSeconds, TimeUnit.SECONDS).maximumSize(maxSize).build();
    }

    private Cache<String, Boolean> verifiedCache;
    private int cacheTtlSeconds = 300;
    private int cacheCleanupIntervalMinutes = 5;
    private boolean viaPresent = false;
    private boolean geyserPresent = false;
    private final Map<java.util.UUID, Integer> playerProtocolVersion = new ConcurrentHashMap<>();
    private final Map<String, String> bedrockXuidToJavaUuid = new ConcurrentHashMap<>();

    public void handlePlayerJoin(Player player) {
        if (!this.plugin.areManagersInitialized()) {
            String startupMessage = "\u00a7c==================================\n\u00a7c\u26a0 Verification System Starting\n\u00a7cPlease reconnect in 30 seconds\n\u00a7c==================================";
            player.kickPlayer(startupMessage);
            return;
        }
        this.plugin.getServer().getScheduler().runTaskAsynchronously((Plugin)this.plugin, () -> {
            try {
                String playerIP = player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : null;
                boolean dbVerifiedByUUID = false;
                boolean dbVerifiedByName = false;
                boolean isWhitelisted = false;
                boolean isIPVerified = false;
                boolean isUUIDTracked = false;
                boolean cacheVerified = false;

                // Check whitelist - prefer checking the online Player (by UUID), fallback to name lookup
                try {
                    isWhitelisted = player.isWhitelisted();
                    if (!isWhitelisted) {
                        isWhitelisted = this.isWhitelisted(player.getName());
                    }
                } catch (Exception e) {
                    isWhitelisted = false;
                }

                // Check database by UUID and by player name
                // Check in-memory verification cache first
                try {
                    cacheVerified = this.isCachedVerified(player.getUniqueId().toString(), player.getName());
                } catch (Exception e) {
                    cacheVerified = false;
                }
                if (cacheVerified) {
                    // skip DB/IP checks when cached verified
                }
                
                if (this.databaseManager != null) {
                    try {
                        dbVerifiedByUUID = cacheVerified || this.databaseManager.isPlayerVerified(player.getUniqueId().toString()).join();
                    } catch (Exception e) {
                        dbVerifiedByUUID = false;
                    }
                    try {
                        dbVerifiedByName = cacheVerified || this.databaseManager.checkPlayerExists(player.getName()).join();
                    } catch (Exception e) {
                        dbVerifiedByName = false;
                    }
                }

                // Check IP verification (optional)
                if (playerIP != null && this.databaseManager != null) {
                    try {
                        isIPVerified = this.databaseManager.isIPFromVerifiedAccount(playerIP).join();
                    } catch (Exception e) {
                        this.plugin.getLogger().warning("Error checking IP verification: " + e.toString());
                    }
                }

                // Check if UUID is in tracked file (player has tried to join before)
                if (this.plugin.getIPTracker() != null) {
                    isUUIDTracked = this.plugin.getIPTracker().isUUIDTracked(player.getUniqueId().toString());
                }

                // If Geyser/Floodgate is present, try to fetch Bedrock XUID and protocol version
                try {
                    if (this.geyserPresent) {
                        try {
                            String bedrockXuid = getFloodgateXuid(player);
                            if (bedrockXuid != null) {
                                this.bedrockXuidToJavaUuid.put(bedrockXuid, player.getUniqueId().toString());
                                // also put a cached verified entry if applicable
                                this.verifiedCache.put("x:" + bedrockXuid, Boolean.TRUE);
                            }
                        } catch (Throwable t) {
                            // ignore
                        }
                    }
                    if (this.viaPresent) {
                        try {
                            Integer proto = getViaProtocolVersion(player);
                            if (proto != null) this.playerProtocolVersion.put(player.getUniqueId(), proto);
                        } catch (Throwable t) {
                            // ignore
                        }
                    }
                } catch (Throwable ignored) {}

                final boolean finalDbVerified = dbVerifiedByUUID || dbVerifiedByName;
                final boolean finalCacheVerified = cacheVerified;
                final boolean finalIsNameVerified = dbVerifiedByName;
                final boolean finalIsWhitelisted = isWhitelisted;
                final boolean finalIsIPVerified = isIPVerified;
                final boolean finalIsUUIDTracked = isUUIDTracked;
                
                this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
                    // Debug: log computed verification flags
                    if (this.plugin.getConfig().getBoolean("logging.log-verifications", true)) {
                        this.plugin.getLogger().info("[VerifyX] Verification flags - DB:" + finalDbVerified + " Cache:" + finalCacheVerified + " NameVerified:" + finalIsNameVerified + " Whitelist:" + finalIsWhitelisted + " IPVerified:" + finalIsIPVerified + " UUIDTracked:" + finalIsUUIDTracked);
                    }
                    // Require BOTH a database verification (by UUID or name) AND whitelist to bypass OTP.
                    if (!((finalDbVerified || finalCacheVerified) && finalIsWhitelisted) && !finalIsIPVerified) {
                        // Record this join attempt with IP for later forceverify
                        if (playerIP != null && this.plugin.getIPTracker() != null) {
                            this.plugin.getIPTracker().recordPlayerIP(player.getName(), playerIP, player.getUniqueId().toString());
                        }
                        
                                // If strict 1-account-per-IP policy is enabled, block immediately when another account exists on the IP
                                try {
                                    int maxAlts = this.plugin.getConfig().getInt("ai-security.max-alts-per-ip", 2);
                                    if (maxAlts <= 1 && playerIP != null && this.aiSecurityManager != null) {
                                        java.util.Set<String> accountsOnIP = this.aiSecurityManager.getAccountsOnIP(playerIP);
                                        if (accountsOnIP != null && !accountsOnIP.isEmpty()) {
                                            // if another UUID is present on this IP (not just this player's own uuid), treat as alt
                                            boolean conflict = !(accountsOnIP.size() == 1 && accountsOnIP.contains(player.getUniqueId().toString()));
                                            if (conflict) {
                                                this.handleAltAccount(player);
                                                return;
                                            }
                                        }
                                    }
                                } catch (Exception ignored) {}

                                // Check explicit alt detection first, then AI OTP allowance as a fallback
                                if (this.aiSecurityManager != null) {
                                    try {
                                        if (this.aiSecurityManager.isPlayerAlt(player.getName())) {
                                            // If server configured to allow alts without OTP enforcement, let them join (unverified)
                                            boolean altOtpEnabled = true;
                                            try {
                                                if (this.plugin.getConfig().contains("ai-security.alt_otp")) {
                                                    altOtpEnabled = this.plugin.getConfig().getBoolean("ai-security.alt_otp", true);
                                                } else {
                                                    // backward-compat: if config uses prevent-alt-otp, invert it
                                                    altOtpEnabled = !this.plugin.getConfig().getBoolean("ai-security.prevent-alt-otp", true);
                                                }
                                            } catch (Exception ignored) {}
                                            if (!altOtpEnabled) {
                                                // alt_otp: false means ALLOW alts without OTP (they stay unverified but join)
                                                player.sendMessage("\u00a76\u00a7l⚠ NOTICE\u00a7r\u00a7e: Your account is flagged as an alt account. You are allowed to join but remain \u00a7cunverified\u00a7e.");
                                                // Allow join (skip OTP), update tab to unverified and continue
                                                try {
                                                    if (this.plugin.getVerifyTab() != null) this.plugin.getVerifyTab().updatePlayerTab(player);
                                                } catch (Exception ignored) {}
                                                return;
                                            }
                                            // alt_otp: true means ENFORCE OTP for alts (kick with OTP)
                                            this.handleAltAccount(player);
                                            return;
                                        }
                                    } catch (Exception ignored) {}
                                    boolean canOtp = true;
                                    try {
                                        canOtp = this.aiSecurityManager.canGenerateOTP(player.getName(), player.getUniqueId().toString(), playerIP != null ? playerIP : "unknown");
                                    } catch (Exception ignored) {}
                                    if (!canOtp) {
                                        this.handleAltAccount(player);
                                        return;
                                    }
                                    
                                    // Check if this is a returning alt with alt_otp disabled
                                    // Don't rely on isPlayerAlt() as it may have stale state after canGenerateOTP() call
                                    boolean altOtpEnabled = true;
                                    try {
                                        if (this.plugin.getConfig().contains("ai-security.alt_otp")) {
                                            altOtpEnabled = this.plugin.getConfig().getBoolean("ai-security.alt_otp", true);
                                        } else {
                                            altOtpEnabled = !this.plugin.getConfig().getBoolean("ai-security.prevent-alt-otp", true);
                                        }
                                    } catch (Exception ignored) {}
                                    
                                    if (!altOtpEnabled && this.aiSecurityManager != null && playerIP != null) {
                                        java.util.Set<String> accountsOnIP = this.aiSecurityManager.getAccountsOnIP(playerIP);
                                        int maxAlts = this.plugin.getConfig().getInt("ai-security.max-alts-per-ip", 2);
                                        if (accountsOnIP != null && accountsOnIP.size() >= maxAlts) {
                                            // This IP has reached max accounts and alt_otp is disabled, allow alt to join unverified
                                            player.sendMessage("\u00a76\u00a7l⚠ NOTICE\u00a7r\u00a7e: Your account is flagged as an alt account. You are allowed to join but remain \u00a7cunverified\u00a7e.");
                                            try {
                                                if (this.plugin.getVerifyTab() != null) this.plugin.getVerifyTab().updatePlayerTab(player);
                                            } catch (Exception ignored) {}
                                            return;
                                        }
                                    }
                                }
                        String otp = this.otpManager.generateOTP(player.getName(), player.getUniqueId().toString(), playerIP != null ? playerIP : "unknown");
                        if (otp == null) {
                            this.handleAltAccount(player);
                            return;
                        }
                        String kickMessage = this.createKickMessage(otp);
                        player.kickPlayer(kickMessage);
                        this.plugin.getLogger().info("Kicked " + player.getName() + " with OTP: " + otp);
                    } else {
                        String reason;
                        if (finalDbVerified) {
                            if (finalIsWhitelisted) reason = "Whitelisted";
                            else if (finalIsNameVerified) reason = "Name verified";
                            else reason = "UUID verified";
                        } else if (finalIsIPVerified) {
                            reason = "IP verified (alt account)";
                        } else {
                            reason = "Unknown";
                        }
                        player.sendMessage("\u00a7a\u2705 Welcome back, " + player.getName() + "!");
                        this.plugin.getLogger().info("\u2705 Verified player joined: " + player.getName() + " (" + reason + ")");
                        WorldManager wm = this.getWorldManager();
                        if (wm != null && wm.isWorldReady()) {
                            wm.teleportToMainWorld(player);
                        }
                        // Update tab display for verified player
                        try {
                            if (this.plugin.getVerifyTab() != null) {
                                this.plugin.getVerifyTab().updatePlayerTab(player);
                            }
                        } catch (Exception e) {
                            this.plugin.getLogger().warning("Error updating verify tab for " + player.getName() + ": " + e.toString());
                        }
                    }
                });
            }
            catch (Exception e) {
                this.plugin.getLogger().warning("Error handling player join for " + player.getName() + ": " + e.toString());
                String errorMessage = "\u00a7c==================================\n\u00a7c\u274c Verification Error\n\u00a7cPlease try again later\n\u00a7c==================================";
                player.kickPlayer(errorMessage);
            }
        });
    }

    private void handleAltAccount(Player player) {
        String altMessage = String.valueOf(ChatColor.RED) + "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\n" + String.valueOf(ChatColor.RED) + "\u26a0\ufe0f  ALT ACCOUNT DETECTED!\n" + String.valueOf(ChatColor.YELLOW) + "Our security system has flagged this as an alt account.\n" + String.valueOf(ChatColor.YELLOW) + "Please join with your main account.\n" + String.valueOf(ChatColor.RED) + "OTP verification is not available for alt accounts.\n" + String.valueOf(ChatColor.RED) + "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550";
        player.kickPlayer(altMessage);
        this.plugin.getLogger().warning("\ud83d\udeab Alt account blocked: " + player.getName());
    }
    

    private String createKickMessage(String otp) {
        return "\u00a7c==================================\n\u00a7c\u26a0 VERIFICATION REQUIRED\n\u00a7c\n\u00a7cJoin our Discord server\n\u00a7cGo to #verification channel\n\u00a7cClick \"Start Verification\" button\n\u00a7cEnter this OTP code:\n\u00a7e" + otp + "\n\u00a7c\n\u00a7cCode expires in 10 minutes\n\u00a7cMax 3 attempts allowed\n\u00a7c==================================";
    }

    public WorldManager getWorldManager() {
        if (this.worldManager == null && !this.worldManagerInitializing) {
            this.worldManagerInitializing = true;
            this.plugin.getLogger().info("\ud83d\ude80 Initializing WorldManager...");
            new BukkitRunnable(){

                public void run() {
                    try {
                        VerificationManager.this.worldManager = new WorldManager(VerificationManager.this.plugin);
                        VerificationManager.this.worldManagerReady = true;
                        VerificationManager.this.plugin.getLogger().info("\u2705 WorldManager initialized successfully");
                    }
                    catch (Exception e) {
                        VerificationManager.this.plugin.getLogger().severe("\u274c Failed to initialize WorldManager: " + e.toString());
                        e.printStackTrace();
                    }
                    finally {
                        VerificationManager.this.worldManagerInitializing = false;
                    }
                }
            }.runTask((Plugin)this.plugin);
        }
        return this.worldManager;
    }

    public boolean isWorldManagerReady() {
        return this.worldManager != null && this.worldManagerReady;
    }


    public boolean isPlayerVerified(Player player) {
        try {
            if (this.databaseManager == null) {
                this.plugin.getLogger().warning("DatabaseManager is null, cannot check verification for: " + player.getName());
                return false;
            }
            return this.databaseManager.isPlayerVerified(player.getUniqueId().toString()).join();
        }
        catch (Exception e) {
            this.plugin.getLogger().warning("Error checking verification for " + player.getName() + ": " + e.toString());
            return false;
        }
    }

    public CompletableFuture<Boolean> verifyDiscordOTP(String otp, String discordId, String discordName) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return this.otpManager.verifyOTP(otp, discordId);
            }
            catch (Exception e) {
                this.plugin.getLogger().warning("Error in Discord OTP verification: " + e.toString());
                return false;
            }
        });
    }

    public void addToWhitelist(String playerName, String playerUUID) {
        this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
            this.plugin.getLogger().info("\u2699\ufe0f Adding " + playerName + " to whitelist...");
                OfflinePlayer offlinePlayer = null;
                try {
                    try {
                        offlinePlayer = Bukkit.getOfflinePlayer((UUID)UUID.fromString(playerUUID));
                    } catch (IllegalArgumentException e) {
                        offlinePlayer = Bukkit.getOfflinePlayer((String)playerName);
                    }
                    this.plugin.getLogger().info("\u2699 Adding to whitelist -> resolved offline player UUID: " + (offlinePlayer != null ? offlinePlayer.getUniqueId().toString() : "null") );
                    if (offlinePlayer != null) {
                        offlinePlayer.setWhitelisted(true);
                    }
                    try {
                        Bukkit.reloadWhitelist();
                        this.plugin.getLogger().info("\u2705 Added " + playerName + " to whitelist (reload done)");
                    } catch (Exception ex) {
                        this.plugin.getLogger().warning("Failed to reload whitelist synchronously: " + ex.getMessage());
                    }
                    // Ensure server-level whitelist mapping by dispatching console command
                    try {
                        Bukkit.dispatchCommand((org.bukkit.command.CommandSender)Bukkit.getConsoleSender(), (String)("whitelist add " + playerName));
                        Bukkit.dispatchCommand((org.bukkit.command.CommandSender)Bukkit.getConsoleSender(), (String)"whitelist reload");
                        this.plugin.getLogger().info("\u2705 Ensured server-level whitelist entry for " + playerName);
                    } catch (Exception ex2) {
                        this.plugin.getLogger().warning("Failed to dispatch whitelist command fallback: " + ex2.getMessage());
                    }
                    // Diagnostic: list whitelisted players count and whether contains UUID
                    try {
                        int count = Bukkit.getWhitelistedPlayers().size();
                        boolean contains = false;
                        if (offlinePlayer != null) {
                            for (org.bukkit.OfflinePlayer op : Bukkit.getWhitelistedPlayers()) {
                                if (op != null && op.getUniqueId() != null && op.getUniqueId().equals(offlinePlayer.getUniqueId())) {
                                    contains = true;
                                    break;
                                }
                            }
                        }
                        this.plugin.getLogger().info("[VerifyX] Whitelist state -> total:" + count + " containsPlayerUUID:" + contains);
                        // cache verification immediately to avoid DB race on join
                        try {
                            VerificationManager.this.cacheVerified(playerUUID, playerName);
                            // also cache Bedrock XUID mapping if available
                            try {
                                String xuid = getFloodgateXuid(offlinePlayer != null ? Bukkit.getPlayer(offlinePlayer.getUniqueId()) : null);
                                if (xuid != null) {
                                    VerificationManager.this.verifiedCache.put("x:" + xuid, Boolean.TRUE);
                                    VerificationManager.this.bedrockXuidToJavaUuid.put(xuid, playerUUID);
                                }
                            } catch (Throwable ignored) {
                            }
                        } catch (Exception ex4) {
                            this.plugin.getLogger().warning("Failed to cache verification for " + playerName + ": " + ex4.getMessage());
                        }
                            // Update the tab display for the player if online
                            try {
                                Player online = Bukkit.getPlayer((String)playerName);
                                if (online != null && online.isOnline() && this.plugin.getVerifyTab() != null) {
                                    try { this.plugin.getVerifyTab().setPlayerVerified(online); } catch (Throwable ignored) {}
                                }
                            } catch (Exception ignored) {}
                    } catch (Exception ex3) {
                        this.plugin.getLogger().warning("Error checking whitelist state: " + ex3.getMessage());
                    }
            }
            catch (Exception e) {
                this.plugin.getLogger().severe("\u274c Error adding to whitelist: " + e.toString());
                try {
                    Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)("whitelist add " + playerName));
                    Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)"whitelist reload");
                    this.plugin.getLogger().info("\u2705 Used fallback method to whitelist " + playerName);
                }
                catch (Exception ex) {
                    this.plugin.getLogger().severe("\u274c Fallback whitelist method also failed: " + ex.getMessage());
                }
            }
        });
    }

    public void removeFromWhitelist(String playerName) {
        this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
            this.plugin.getLogger().info("\u2699\ufe0f Removing " + playerName + " from whitelist...");
            try {
                OfflinePlayer player = Bukkit.getOfflinePlayer((String)playerName);
                if (player != null) {
                    player.setWhitelisted(false);
                    try {
                        Bukkit.reloadWhitelist();
                        this.plugin.getLogger().info("\u2705 Removed " + playerName + " from whitelist");
                    } catch (Exception ex) {
                        this.plugin.getLogger().warning("Failed to reload whitelist synchronously: " + ex.getMessage());
                    }
                    // Ensure server-level whitelist file is updated by dispatching console commands
                    try {
                        Bukkit.dispatchCommand((org.bukkit.command.CommandSender)Bukkit.getConsoleSender(), (String)("whitelist remove " + playerName));
                        Bukkit.dispatchCommand((org.bukkit.command.CommandSender)Bukkit.getConsoleSender(), (String)"whitelist reload");
                        this.plugin.getLogger().info("\u2705 Dispatched whitelist remove for " + playerName);
                    } catch (Exception ex2) {
                        this.plugin.getLogger().warning("Failed to dispatch whitelist remove fallback: " + ex2.getMessage());
                    }
                    Player onlinePlayer = Bukkit.getPlayer((String)playerName);
                    if (onlinePlayer != null && onlinePlayer.isOnline()) {
                        String kickMessage = "\u00a7c==================================\n\u00a7c\u274c You have been unverified\n\u00a7c\n\u00a7cYour verification has been removed\n\u00a7cPlease re-verify in Discord\n\u00a7c\n\u00a7cJoin #verification channel\n\u00a7c==================================";
                        onlinePlayer.kickPlayer(kickMessage);
                        this.plugin.getLogger().info("\u2705 Kicked online player " + playerName);
                    }
                } else {
                    this.plugin.getLogger().warning("Player " + playerName + " not found for whitelist removal");
                    Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)("whitelist remove " + playerName));
                    Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)"whitelist reload");
                }
            }
            catch (Exception e) {
                this.plugin.getLogger().severe("\u274c Error removing from whitelist: " + e.toString());
                try {
                    Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)("whitelist remove " + playerName));
                    Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)"whitelist reload");
                    this.plugin.getLogger().info("\u2705 Used fallback whitelist removal for " + playerName);
                    Player onlinePlayer = Bukkit.getPlayer((String)playerName);
                    if (onlinePlayer != null && onlinePlayer.isOnline()) {
                        String kickMessage = "\u00a7c==================================\n\u00a7c\u274c You have been unverified\n\u00a7c\n\u00a7cYour verification has been removed\n\u00a7cPlease re-verify in Discord\n\u00a7c==================================";
                        onlinePlayer.kickPlayer(kickMessage);
                    }
                }
                catch (Exception ex) {
                    this.plugin.getLogger().severe("\u274c Fallback whitelist removal also failed: " + ex.getMessage());
                }
            }
        });
    }

    public boolean isWhitelisted(String playerName) {
        OfflinePlayer player = Bukkit.getOfflinePlayer((String)playerName);
        return player != null && player.isWhitelisted();
    }

    public int getWhitelistCount() {
        return Bukkit.getWhitelistedPlayers().size();
    }

    public void whitelistPlayer(String playerName) {
        this.addToWhitelist(playerName, "");
    }

    public void reloadConfig() {
        this.plugin.reloadConfig();
        this.plugin.getLogger().info("\u2705 Configuration reloaded");
    }

    public void cacheVerified(String playerUUID, String playerName) {
        if (playerUUID != null && !playerUUID.isEmpty()) {
            this.verifiedCache.put("u:" + playerUUID, Boolean.TRUE);
        }
        if (playerName != null && !playerName.isEmpty()) {
            this.verifiedCache.put("n:" + playerName.toLowerCase(), Boolean.TRUE);
        }
        if (this.plugin.getConfig().getBoolean("logging.log-verifications", true)) {
            this.plugin.getLogger().info("[VerifyX] Cached verification for " + playerName + " (ttl=" + this.cacheTtlSeconds + "s)");
        }
        try {
            if (playerUUID != null && !playerUUID.isEmpty()) {
                for (Map.Entry<String, String> e : this.bedrockXuidToJavaUuid.entrySet()) {
                    if (playerUUID.equals(e.getValue())) {
                        this.verifiedCache.put("x:" + e.getKey(), Boolean.TRUE);
                        break;
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    public void invalidateCachedVerification(String playerUUID, String playerName) {
        try {
            if (playerUUID != null && !playerUUID.isEmpty()) {
                this.verifiedCache.invalidate("u:" + playerUUID);
            }
            if (playerName != null && !playerName.isEmpty()) {
                this.verifiedCache.invalidate("n:" + playerName.toLowerCase());
            }
            // remove any bedrock mapping entries for this UUID
            try {
                java.util.Iterator<java.util.Map.Entry<String, String>> it = this.bedrockXuidToJavaUuid.entrySet().iterator();
                while (it.hasNext()) {
                    java.util.Map.Entry<String, String> e = it.next();
                    if (playerUUID != null && playerUUID.equals(e.getValue())) {
                        this.verifiedCache.invalidate("x:" + e.getKey());
                        it.remove();
                    }
                }
            } catch (Throwable ignored) {}
            if (this.plugin.getConfig().getBoolean("logging.log-verifications", true)) {
                this.plugin.getLogger().info("[VerifyX] Invalidated cached verification for " + playerName + " (" + playerUUID + ")");
            }
        } catch (Exception e) {
            this.plugin.getLogger().warning("Failed to invalidate cached verification for " + playerName + ": " + e.toString());
        }
    }

    // Public helper to cache a Bedrock XUID mapping to a Java UUID
    public void cacheBedrockXuid(String xuid, String playerUUID) {
        if (xuid == null || xuid.isEmpty() || playerUUID == null || playerUUID.isEmpty()) return;
        try {
            this.bedrockXuidToJavaUuid.put(xuid, playerUUID);
            this.verifiedCache.put("x:" + xuid, Boolean.TRUE);
            if (this.plugin.getConfig().getBoolean("logging.log-verifications", true)) {
                this.plugin.getLogger().info("[VerifyX] Cached Bedrock XUID mapping: " + xuid + " -> " + playerUUID);
            }
        } catch (Exception ignored) {}
    }

    

    public boolean isCachedVerified(String playerUUID, String playerName) {
        if (playerUUID != null && !playerUUID.isEmpty()) {
            String key = "u:" + playerUUID;
            Boolean v = this.verifiedCache.getIfPresent(key);
            if (v != null && v) return true;
        }
        if (playerName != null && !playerName.isEmpty()) {
            String key2 = "n:" + playerName.toLowerCase();
            Boolean v2 = this.verifiedCache.getIfPresent(key2);
            if (v2 != null && v2) return true;
        }
        // also check bedrock xuid key
        try {
            if (playerUUID != null && !playerUUID.isEmpty()) {
                for (Map.Entry<String, String> e : this.bedrockXuidToJavaUuid.entrySet()) {
                    if (playerUUID.equals(e.getValue())) {
                        Boolean xv = this.verifiedCache.getIfPresent("x:" + e.getKey());
                        if (xv != null && xv) return true;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    public String getFloodgateXuid(Player player) {
        if (player == null) return null;
        try {
            Class<?> floodgateApiClass = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
            Method getInstance = floodgateApiClass.getMethod("getInstance");
            Object api = getInstance.invoke(null);
            Method isFg = floodgateApiClass.getMethod("isFloodgatePlayer", java.util.UUID.class);
            Boolean is = (Boolean)isFg.invoke(api, player.getUniqueId());
            if (!is) return null;
            Method getPlayer = floodgateApiClass.getMethod("getPlayer", java.util.UUID.class);
            Object fgPlayer = getPlayer.invoke(api, player.getUniqueId());
            if (fgPlayer == null) return null;
            try {
                Method getXuid = fgPlayer.getClass().getMethod("getXuid");
                Object x = getXuid.invoke(fgPlayer);
                if (x != null) return x.toString();
            } catch (NoSuchMethodException ignored) {}
            try {
                Method getXboxUuid = fgPlayer.getClass().getMethod("getXboxUUID");
                Object x = getXboxUuid.invoke(fgPlayer);
                if (x != null) return x.toString();
            } catch (NoSuchMethodException ignored) {}
            try {
                Method getXboxUniqueId = fgPlayer.getClass().getMethod("getXboxUniqueId");
                Object x = getXboxUniqueId.invoke(fgPlayer);
                if (x != null) return x.toString();
            } catch (NoSuchMethodException ignored) {}
        } catch (Throwable t) {
            // ignore
        }
        return null;
    }

    private Integer getViaProtocolVersion(Player player) {
        if (player == null) return null;
        try {
            Class<?> viaClass = Class.forName("us.myles.ViaVersion.api.Via");
            Method getAPI = viaClass.getMethod("getAPI");
            Object api = getAPI.invoke(null);
            Method getPlayerVersion = api.getClass().getMethod("getPlayerVersion", java.util.UUID.class);
            Object res = getPlayerVersion.invoke(api, player.getUniqueId());
            if (res instanceof Integer) return (Integer)res;
        } catch (Throwable ignored) {}
        try {
            Class<?> viaApiClass = Class.forName("us.myles.ViaVersion.api.ViaAPI");
            Method getInstance = viaApiClass.getMethod("getInstance");
            Object api = getInstance.invoke(null);
            Method getPlayerVersion = api.getClass().getMethod("getPlayerVersion", java.util.UUID.class);
            Object res = getPlayerVersion.invoke(api, player.getUniqueId());
            if (res instanceof Integer) return (Integer)res;
        } catch (Throwable ignored) {}
        return null;
    }
}

