package io.verifyx.util;

import io.verifyx.Main;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class IPTracker {
    private final Main plugin;
    private final File dataFolder;
    private final File ipFile;
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public IPTracker(Main plugin) {
        this.plugin = plugin;
        this.dataFolder = plugin.getDataFolder();
        this.ipFile = new File(this.dataFolder, "player_ips.txt");
        this.ensureFileExists();
    }

    private void ensureFileExists() {
        try {
            if (!this.dataFolder.exists()) {
                this.dataFolder.mkdirs();
            }
            if (!this.ipFile.exists()) {
                this.ipFile.createNewFile();
                this.plugin.getLogger().info("✓ Created player_ips.txt tracking file");
            }
        } catch (Exception e) {
            this.plugin.getLogger().warning("Error creating IP tracking file: " + e.toString());
        }
    }

    public synchronized void recordPlayerIP(String playerName, String ipAddress, String playerUUID) {
        try {
            String timestamp = LocalDateTime.now().format(formatter);
            String entry = String.format("%s | UUID: %s | IP: %s | Time: %s%n", 
                    playerName, playerUUID, ipAddress, timestamp);
            
            // Append to file
            try (FileWriter writer = new FileWriter(this.ipFile, true)) {
                writer.append(entry);
            }
            
            this.plugin.getLogger().info("✓ Recorded IP for " + playerName + " (" + ipAddress + ")");
        } catch (Exception e) {
            this.plugin.getLogger().warning("Error recording player IP: " + e.toString());
        }
    }

    public String getPlayerIP(String playerName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(this.ipFile))) {
            String line;
            String lastIP = null;
            
            // Read all entries, keep the most recent IP for this player
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(playerName + " |")) {
                    // Extract IP from line: "playerName | UUID: xxx | IP: 192.168.1.100 | Time: ..."
                    String[] parts = line.split("\\|");
                    for (String part : parts) {
                        part = part.trim();
                        if (part.startsWith("IP:")) {
                            lastIP = part.substring(3).trim();
                            break;
                        }
                    }
                }
            }
            
            if (lastIP != null) {
                this.plugin.getLogger().info("✓ Found IP for " + playerName + ": " + lastIP);
            } else {
                this.plugin.getLogger().info("⚠ No IP history found for " + playerName);
            }
            
            return lastIP;
        } catch (Exception e) {
            this.plugin.getLogger().warning("Error reading player IP: " + e.toString());
            return null;
        }
    }

    public String getLastKnownUUID(String playerName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(this.ipFile))) {
            String line;
            String lastUUID = null;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(playerName + " |")) {
                    String[] parts = line.split("\\|");
                    for (String part : parts) {
                        part = part.trim();
                        if (part.startsWith("UUID:")) {
                            lastUUID = part.substring(5).trim();
                            break;
                        }
                    }
                }
            }
            return lastUUID;
        } catch (Exception e) {
            this.plugin.getLogger().warning("Error reading last known UUID: " + e.toString());
            return null;
        }
    }

    public Map<String, String> getAllPlayerIPs() {
        Map<String, String> playerIPs = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(this.ipFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                
                String[] parts = line.split("\\|");
                if (parts.length >= 2) {
                    String playerName = parts[0].trim();
                    String ipAddress = null;
                    
                    for (String part : parts) {
                        part = part.trim();
                        if (part.startsWith("IP:")) {
                            ipAddress = part.substring(3).trim();
                            break;
                        }
                    }
                    
                    if (ipAddress != null && !playerIPs.containsKey(playerName)) {
                        playerIPs.put(playerName, ipAddress);
                    }
                }
            }
        } catch (Exception e) {
            this.plugin.getLogger().warning("Error reading all player IPs: " + e.toString());
        }
        return playerIPs;
    }

    public File getIPFile() {
        return this.ipFile;
    }

    public boolean isUUIDTracked(String playerUUID) {
        try (BufferedReader reader = new BufferedReader(new FileReader(this.ipFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("UUID: " + playerUUID)) {
                    this.plugin.getLogger().info("✓ Found tracked UUID: " + playerUUID);
                    return true;
                }
            }
        } catch (Exception e) {
            this.plugin.getLogger().warning("Error checking UUID in tracker: " + e.toString());
        }
        return false;
    }
}
